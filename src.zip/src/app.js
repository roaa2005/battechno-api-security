const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const rateLimit = require("express-rate-limit");

const productsRoutes = require("./routes/productsRoutes");
const categoriesRoutes = require("./routes/categoriesRoutes");
const usersRoutes = require("./routes/usersRoutes");
const authRoutes = require("./routes/authRoutes");

const app = express();

app.use(helmet());
app.use(cors({
    origin: ['http://localhost:5173'], 
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());

const generalLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 100 });
app.use(generalLimiter);

const loginLimiter = rateLimit({ 
    windowMs: 15 * 60 * 1000, 
    max: 5, 
    message: { success: false, message: "Too many login attempts" } 
});
app.use('/api/auth/login', loginLimiter);

app.get("/", (req, res) => {
  res.status(200).json({
    success: true,
    message: "E-commerce API is running"
  });
});

app.use("/api/auth", authRoutes);
app.use("/api/products", productsRoutes);
app.use("/api/categories", categoriesRoutes);
app.use("/api/users", usersRoutes);

app.use((req, res) => {
    res.status(404).json({ success: false, message: "Endpoint not found" });
});

app.use((err, req, res, next) => {
    console.error(err.stack); 
    res.status(500).json({ 
        success: false, 
        message: "Internal server error" 
    });
});

module.exports = app;