const express = require("express");
const router = express.Router();

const productsController = require('../controllers/productsController');
const authenticate = require('../middleware/authenticate'); 
const authorize = require('../middleware/authorize'); // استدعاء حارس الصلاحيات

router.get("/", productsController.getProducts);
router.get("/:id", productsController.getProductById);

router.post("/", authenticate, authorize(['admin']), productsController.createProduct);

router.put("/:id", authenticate, productsController.updateProduct);
router.patch("/:id/deactivate", authenticate, productsController.deactivateProduct);

module.exports = router;