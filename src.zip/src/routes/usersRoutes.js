const express = require('express');
const router = express.Router();

const usersController = require('../controllers/usersController');
const authenticate = require('../middleware/authenticate'); 

router.get('/', authenticate, usersController.getUsers);
router.get('/:id', authenticate, usersController.getUserById);
router.post('/', authenticate, usersController.createUser);
router.patch('/:id/toggle-status', authenticate, usersController.toggleUserStatus);

module.exports = router;