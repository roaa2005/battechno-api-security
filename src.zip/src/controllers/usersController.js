const pool = require("../config/database");
const bcrypt = require("bcrypt"); 

async function getUsers(req, res) {
  try {
    const result = await pool.query("SELECT id, full_name, email, phone, role, is_active, created_at FROM users ORDER BY id DESC");
    res.status(200).json({ success: true, count: result.rows.length, data: result.rows });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to retrieve users" });
  }
}

async function getUserById(req, res) {
  try {
    const userId = Number(req.params.id);
    if (!Number.isInteger(userId) || userId <= 0) {
      return res.status(400).json({ success: false, message: "Invalid user ID" });
    }

    if (req.user && req.user.id !== userId && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: "Access denied: You can only view your own profile" });
    }

    const result = await pool.query("SELECT id, full_name, email, phone, role, is_active, created_at FROM users WHERE id = $1", [userId]);
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: "User not found" });
    }
    res.status(200).json({ success: true, data: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to retrieve user" });
  }
}

async function createUser(req, res) {
  try {
    let { full_name, email, password, phone, role } = req.body;
    
    if (!full_name || !email || !password) {
      return res.status(400).json({ success: false, message: "full_name, email and password are required" });
    }

    const hashedPassword = await bcrypt.hash(password, 12);

    role = role || 'customer';

    const result = await pool.query(`
      INSERT INTO users (full_name, email, password_hash, phone, role)
      VALUES ($1, $2, $3, $4, $5) RETURNING id, full_name, email, phone, role, is_active, created_at
    `, [full_name, email, hashedPassword, phone || null, role]);

    res.status(201).json({ success: true, message: "User created successfully", data: result.rows[0] });
  } catch (error) {
    if (error.code === "23505") {
      return res.status(409).json({ success: false, message: "Email already exists" });
    }
    res.status(500).json({ success: false, message: "Failed to create user" });
  }
}

async function toggleUserStatus(req, res) {
  try {
    const userId = Number(req.params.id);
    
    if (!Number.isInteger(userId) || userId <= 0) {
      return res.status(400).json({ success: false, message: "Invalid user ID" });
    }

    const result = await pool.query(`
      UPDATE users SET is_active = NOT is_active, updated_at = NOW() 
      WHERE id = $1 RETURNING id, full_name, email, is_active
    `, [userId]);

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: "User not found" });
    }
    
    const statusText = result.rows[0].is_active ? "activated" : "deactivated";
    res.status(200).json({ success: true, message: `User ${statusText} successfully`, data: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to update user status" });
  }
}

module.exports = { getUsers, getUserById, createUser, toggleUserStatus };