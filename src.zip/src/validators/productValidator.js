const { z } = require('zod');

const createProductSchema = z.object({
    name: z.string().min(3, "Product name must be at least 3 characters").max(100, "Name is too long"),
    description: z.string().optional().min(10, "Description must be at least 10 characters"),
    price: z.number({ invalid_type_error: "Price must be a number" }).positive("Price must be greater than zero"),
    stock_quantity: z.number({ invalid_type_error: "Stock must be a number" }).int().nonnegative("Stock cannot be negative")
});

module.exports = { createProductSchema };